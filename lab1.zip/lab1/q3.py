OK_FORMAT = True

test = {   'name': 'q3',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert split_phrase("a") == ["a"]\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert split_phrase("") == []\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
