OK_FORMAT = True

test = {   'name': 'q1',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> f_to_c(32) == 0\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> f_to_c(89.6) == 32\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
