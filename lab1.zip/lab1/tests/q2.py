OK_FORMAT = True

test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert capitalize("a") == "A"\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert capitalize("A") == "A"\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert capitalize("Brenda") == "BRENDA"\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert capitalize("Brenda Rubenstein") == "BRENDA RUBENSTEIN"\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
