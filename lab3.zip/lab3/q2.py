OK_FORMAT = True

test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert sum57([1,2,3,4,5,6,7,8,9]) == 27\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert sum57([]) == 0\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert sum57([4,3,2,1]) == 10\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
